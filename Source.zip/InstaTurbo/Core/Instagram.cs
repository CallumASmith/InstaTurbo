﻿using InstaTurbo.Core.DataModels;
using InstaTurbo.Core.DataModels.Enums;
using Leaf.xNet;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace InstaTurbo.Core
{
    public class Instagram
    {

        public delegate void dgEventRaiser();
        public event dgEventRaiser OnSuccess;
        public event dgEventRaiser OnCancellation;
        public event dgEventRaiser OnError;
        public event dgEventRaiser OnDelay;
        public event dgEventRaiser OnProcess;
        public bool status = true;
        public int Requests { get; private set; } = 0;
        public Stopwatch StopWatch = new Stopwatch();

        public void Turbo(ref TurboRequest account)
        {
            using (var client = new HttpRequest())
            {
                client.IgnoreProtocolErrors = true;
                client.ConnectTimeout = 2000;
                client.KeepAlive = true;
                client.KeepAliveTimeout = 2000;
                client.ReadWriteTimeout = 2000;
                client.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36";
                string csrf = CSRF(client);
                if (csrf == string.Empty)
                {
                    OnError();
                    return;
                }
                if (!Login(client, account, csrf))
                {
                    OnError();
                    return;
                }
                var accountData = AccountData(client);
                if (accountData.Item1 !=  TurboStatus.Success)
                {
                    OnError();
                    return;
                }
                csrf = TextManipulation.GetStringInBetween("csrftoken=", ";", client.Cookies.GetCookieHeader(new Uri("https://www.instagram.com/")), false,false);
                StopWatch.Start();
                string postdata = $"first_name={accountData.Item2.form_data.first_name}&email={accountData.Item2.form_data.email}&username={account.RequestedAlias}&phone_number=&gender={accountData.Item2.form_data.gender}&biography=&external_url=&chaining_enabled=on";
                while (true)
                {                
                    account.Requests = Requests;
                    account.Duration = Convert.ToString(StopWatch.Elapsed);
                    Requests++;
                    if (ChangeName(client, account, postdata, csrf) == true)
                    {
                        OnSuccess();
                        StopWatch.Stop();
                        return;
                    }
                    if (status == false)
                    {
                        OnCancellation();
                        StopWatch.Stop();
                        return;
                    }
                }
            }
        }
        public void Cancel()
        {
            status = false;
        }
        private string CSRF(HttpRequest client)
        {
            try {
                return TextManipulation.GetStringInBetween("{\"csrf_token\":\"", "\"", client.Get("https://www.instagram.com/accounts/login/?source=auth_switcher").ToString(), false, false);
            }
            catch { }
            return string.Empty;
        }
        private Tuple <TurboStatus, AccountData> AccountData(HttpRequest client)
        {
            try {
                string response = client.Get("https://www.instagram.com/accounts/edit/?__a=1").ToString();
                if (!response.Contains("first_name"))
                {
                    return new Tuple<TurboStatus, AccountData>(TurboStatus.Error, new DataModels.AccountData());
                }
                return new Tuple<TurboStatus, AccountData>(TurboStatus.Success, JsonConvert.DeserializeObject<AccountData>(response));
            } catch { }
            return new Tuple<TurboStatus, AccountData>(TurboStatus.Error, new DataModels.AccountData());
        }
        public bool ChangeName(HttpRequest client, TurboRequest account, string data, string csrf)
        {
            try {
                #region Headers
                client.AddHeader("accept", "*/*")
                    .AddHeader("referer", "https://www.instagram.com/accounts/login/?source=auth_switcher")
                    .AddHeader("x-instagram-ajax", "01ad059a0eb4")
                    .AddHeader("x-requested-with", "XMLHttpRequest")
                    .AddHeader("x-ig-app-id", "936619743392459")
                    .AddHeader("x-csrftoken", csrf)
                    .AddHeader("origin", "https://www.instagram.com");
                #endregion
                string response = client.Post("https://www.instagram.com/accounts/edit/", data, "application/x-www-form-urlencoded").ToString();
                if (response.Contains("Please wait a few minutes before you try again"))
                {
                    OnDelay();
                    Thread.Sleep(20000);
                    OnProcess();
                }
                if (response.Contains("{\"status\": \"ok\"}"))
                {
                    return true;
                }
            } catch { Console.WriteLine("WAIT OVER"); }
            return false;
        }
        private bool Login(HttpRequest client, TurboRequest account, string csrf)
        {
            try {
                #region Headers
                client.AddHeader("accept", "*/*")
                    .AddHeader("referer", "https://www.instagram.com/accounts/login/?source=auth_switcher")
                    .AddHeader("x-instagram-ajax", "01ad059a0eb4")
                    .AddHeader("x-requested-with", "XMLHttpRequest")
                    .AddHeader("x-ig-app-id", "936619743392459")
                    .AddHeader("x-csrftoken", csrf)
                    .AddHeader("origin", "https://www.instagram.com");
                #endregion
                string response = client.Post("https://www.instagram.com/accounts/login/ajax/", $"username={account.Username}&password={account.Password}&queryParams=%7B%22source%22%3A%22auth_switcher%22%7D&optIntoOneTap=false", "application/x-www-form-urlencoded").ToString();
                if (response.Contains("\"authenticated\": true"))
                {
                    return true;
                }
            } catch { }
            return false;
        }
    }
}
