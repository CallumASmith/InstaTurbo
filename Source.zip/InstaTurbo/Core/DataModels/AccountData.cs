﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstaTurbo.Core.DataModels
{
    public class FormData
    {
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string email { get; set; }
        public bool is_email_confirmed { get; set; }
        public bool is_phone_confirmed { get; set; }
        public string username { get; set; }
        public string phone_number { get; set; }
        public int gender { get; set; }
        public object birthday { get; set; }
        public string biography { get; set; }
        public string external_url { get; set; }
        public bool chaining_enabled { get; set; }
        public bool presence_disabled { get; set; }
        public bool business_account { get; set; }
        public bool usertag_review_enabled { get; set; }
    }

    public class AccountData
    {
        public FormData form_data { get; set; }
    }
}
