﻿using InstaTurbo.Core.DataModels.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstaTurbo.Core.DataModels
{
    public class TurboRequest : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public Instagram Request = new Instagram();
        private TurboStatus _status = TurboStatus.Proccessing;
        private string _duration = string.Empty;
        private int _requests = 0;
        public TurboRequest(string username, string password, string alias)
        {
            this.Username = username;
            this.Password = password;
            this.RequestedAlias = alias;
            Request.OnSuccess += new Instagram.dgEventRaiser(Success);
            Request.OnError += new Instagram.dgEventRaiser(Error);
            Request.OnCancellation += new Instagram.dgEventRaiser(Canceled);
            Request.OnDelay += new Instagram.dgEventRaiser(Delay);
            Request.OnProcess += new Instagram.dgEventRaiser(Process);

        }
        public void Cancel()
        {
            Request.Cancel();
        }
        private void Success()
        {
            Status = TurboStatus.Success;
        }
        private void Canceled()
        {
            Status = TurboStatus.Canceled;
        }
        private void Delay()
        {
            Status = TurboStatus.Delay;
        }
        private void Process()
        {
            Status = TurboStatus.Proccessing;
        }
        private void Error()
        {
            Status = TurboStatus.Error;
        }

        public string Username { get; set; }
        public string Password { get; set; }
        public string RequestedAlias { get; set; }
        public string Duration { get { return _duration; }
            set
            {
                _duration = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Duration"));
            }
        }
        public int Requests { get { return Request.Requests; }
            set
            {
                _requests = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Requests"));

            }
        }
        public TurboStatus Status { get { return _status; }
            set
            {
                _status = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Status"));
            }
        }
    }
}
