﻿using InstaTurbo.Core;
using InstaTurbo.Core.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace InstaTurbo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            System.Net.ServicePointManager.DefaultConnectionLimit = int.MaxValue;
            InitializeComponent();
            OverviewDatagrid.ItemsSource = Variables.Requests;
            Variables.Window = this;
        }
        private void CopyCredentialsBtn_Click(object sender, RoutedEventArgs e)
        {
            TurboRequest selected = (OverviewDatagrid.SelectedItem as TurboRequest);
            Clipboard.SetText(selected.Username + ":" + selected.Password); 
        }

        private void StopTurboBtn_Click(object sender, RoutedEventArgs e)
        {
            Variables.Requests[OverviewDatagrid.SelectedIndex].Cancel();
        }

        private void AddTurboBtn_Click(object sender, RoutedEventArgs e)
        {
            var account = new Core.DataModels.TurboRequest(EmailTxtbox.Text, PasswordTxtbox.Text, UsernameTxtbox.Text);
            Task task = Task.Factory.StartNew(delegate
            {
                account.Request.Turbo(ref account);
            });
            Variables.Requests.Add(account);

        }
    }
}
